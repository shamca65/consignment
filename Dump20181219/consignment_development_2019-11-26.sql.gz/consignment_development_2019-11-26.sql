﻿# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: localhost (MySQL 5.7.25)
# Database: consignment_development
# Generation Time: 2019-11-26 21:47:16 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table ar_internal_metadata
# ------------------------------------------------------------

LOCK TABLES `ar_internal_metadata` WRITE;
/*!40000 ALTER TABLE `ar_internal_metadata` DISABLE KEYS */;

INSERT INTO `ar_internal_metadata` (`key`, `value`, `created_at`, `updated_at`)
VALUES
	('environment','development','2018-10-27 01:09:06','2018-10-27 01:09:06');

/*!40000 ALTER TABLE `ar_internal_metadata` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table configs
# ------------------------------------------------------------



# Dump of table customers
# ------------------------------------------------------------

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;

INSERT INTO `customers` (`id`, `first_name`, `last_name`, `created_at`, `updated_at`, `phone`, `email`, `active`, `acct_open_date`, `last_trans_date`, `trans_type`, `agreement_status`, `province`, `street_address`, `street_address2`, `city`, `postal`, `notes`)
VALUES
	(1,'Shaun','McArthur','2018-01-01 01:00:00','2019-11-14 20:46:51','519-473-8855','shamca@bell.net',1,'2018-12-16 00:00:00','2018-12-16 00:00:00',1,1,'ON','65 Hampton Cres	','near the pile of cow poo','London	','N6H 2P1','These are some notes for you.These are some notes for you.These are some notes for you.These are some notes for you.These are some notes for you.These are some notes for you.These are some notes for you.These are some notes for you.These are some notes for you.These are some notes for you.These are some notes for you.These are some notes for you.These are some notes for you.These are some notes for you.These are some notes for you.These are some notes for you.These are some notes for you.These are some notes for you.These are some notes for you.These are some notes for you.These are some notes for you.These are some notes for you.These are some notes for you.These are some notes for you.These are some notes for you.These are some notes for you.'),
	(2,'2-Biff','McFarterWooHoo','2018-10-28 21:23:13','2018-12-18 23:52:23','555-555-1212','biff@anus.com',1,NULL,'2018-12-18 00:00:00',1,1,NULL,NULL,NULL,NULL,NULL,NULL),
	(3,'2-Biff','McFarter','2018-10-28 21:23:52','2018-12-16 23:09:01','555-555-1212','biff@anus.com',1,NULL,'2018-12-16 00:00:00',1,1,NULL,NULL,NULL,NULL,NULL,NULL),
	(4,'2-Biff','McFarter','2018-10-28 21:25:06','2018-12-16 23:08:27','555-555-1212','biff@anus.com',1,NULL,'2018-12-16 00:00:00',1,1,NULL,NULL,NULL,NULL,NULL,NULL),
	(5,'3-Chiff','McFarter','2018-10-28 21:25:07','2018-10-28 21:25:07','555-555-1212','chiff@anus.com',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(6,'Shaun','McArthur','2018-10-29 00:12:52','2018-12-16 22:53:26','5196436458','',1,'2018-12-05 00:00:00','2018-12-16 00:00:00',1,1,NULL,NULL,NULL,NULL,NULL,NULL),
	(7,'Shaun','Katzenberger','2019-11-13 20:18:17','2019-11-13 20:18:17','5196436458','shamca@bell.net',NULL,'2019-11-13 00:00:00','2019-11-13 00:00:00',0,0,'DU','65 Hampton ','','London','N6H2P1',NULL),
	(8,'Shaun','Mcarthur34','2019-11-13 20:58:16','2019-11-13 20:58:16','5196436458','shamca@bell.net',NULL,'2019-11-13 00:00:00','2019-11-13 00:00:00',0,0,'DU','65 Hampton Cres','','','',NULL),
	(9,'Bill','Saskachewan','2019-11-13 21:13:33','2019-11-13 21:13:33','5196436458','shamca@bell.net',NULL,'2019-11-13 00:00:00','2019-11-13 00:00:00',0,0,'SK','65 Hampton Cres','','London','N6H345',NULL),
	(10,'Shaun','McArthur','2019-11-14 19:54:02','2019-11-14 19:54:02','5196436458','shamca@bell.net',NULL,'2019-11-14 00:00:00','2019-11-14 00:00:00',0,0,'','65 Hampton Cres','','','',NULL);

/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table event_logs
# ------------------------------------------------------------

LOCK TABLES `event_logs` WRITE;
/*!40000 ALTER TABLE `event_logs` DISABLE KEYS */;

INSERT INTO `event_logs` (`id`, `created_at`, `updated_at`, `record_type`, `record_id`, `record_action`)
VALUES
	(1,'2018-10-28 22:41:16','2018-10-28 22:41:16',NULL,NULL,NULL),
	(2,'2018-10-28 23:01:12','2018-10-28 23:01:12',NULL,NULL,NULL),
	(3,'2018-10-28 23:01:20','2018-10-28 23:01:20',NULL,NULL,NULL),
	(4,'2018-10-28 23:02:52','2018-10-28 23:02:52',NULL,NULL,NULL),
	(5,'2018-10-28 23:03:31','2018-10-28 23:03:31',NULL,NULL,NULL),
	(6,'2018-10-28 23:03:46','2018-10-28 23:03:46',NULL,NULL,NULL),
	(7,'2018-10-28 23:04:20','2018-10-28 23:04:20',NULL,NULL,NULL),
	(8,'2018-10-28 23:18:01','2018-10-28 23:18:01','Item',36,'created'),
	(9,'2018-10-29 00:12:52','2018-10-29 00:12:52','Customer',6,'created'),
	(10,'2018-10-29 00:13:11','2018-10-29 00:13:11','Customer',2,'udpated'),
	(11,'2018-10-31 22:54:09','2018-10-31 22:54:09','User',1,'udpated'),
	(12,'2018-11-06 00:58:45','2018-11-06 00:58:45','User',1,'udpated'),
	(13,'2018-11-06 01:03:56','2018-11-06 01:03:56','User',1,'udpated'),
	(14,'2018-11-06 01:06:51','2018-11-06 01:06:51','User',1,'udpated'),
	(15,'2018-11-06 01:10:37','2018-11-06 01:10:37','User',1,'udpated'),
	(16,'2018-11-06 01:22:26','2018-11-06 01:22:26','User',1,'udpated'),
	(17,'2018-11-06 01:22:39','2018-11-06 01:22:39','Item',5,'udpated'),
	(18,'2018-11-06 01:41:07','2018-11-06 01:41:07','Item',3,'deleted'),
	(19,'2018-11-06 01:41:12','2018-11-06 01:41:12','User',1,'udpated'),
	(20,'2018-11-06 01:44:06','2018-11-06 01:44:06','User',1,'udpated'),
	(21,'2018-11-08 00:08:10','2018-11-08 00:08:10','User',1,'udpated'),
	(22,'2018-11-08 02:27:04','2018-11-08 02:27:04','User',1,'udpated'),
	(23,'2018-11-08 02:32:08','2018-11-08 02:32:08','User',1,'udpated'),
	(24,'2018-11-08 02:34:20','2018-11-08 02:34:20','User',1,'udpated'),
	(25,'2018-11-08 02:47:45','2018-11-08 02:47:45','User',1,'udpated'),
	(26,'2018-11-08 02:50:13','2018-11-08 02:50:13','User',1,'udpated'),
	(27,'2018-11-09 00:57:59','2018-11-09 00:57:59','User',1,'udpated'),
	(28,'2018-11-11 00:58:33','2018-11-11 00:58:33','User',1,'udpated'),
	(29,'2018-11-11 01:27:31','2018-11-11 01:27:31','User',1,'udpated'),
	(30,'2018-11-11 02:07:38','2018-11-11 02:07:38','User',1,'udpated'),
	(31,'2018-11-11 02:09:22','2018-11-11 02:09:22','User',1,'udpated'),
	(32,'2018-11-11 02:38:20','2018-11-11 02:38:20','User',1,'udpated'),
	(33,'2018-11-11 14:36:43','2018-11-11 14:36:43','User',1,'udpated'),
	(34,'2018-11-14 00:01:40','2018-11-14 00:01:40','User',1,'udpated'),
	(35,'2018-11-14 12:00:27','2018-11-14 12:00:27','User',1,'udpated'),
	(36,'2018-11-14 12:00:37','2018-11-14 12:00:37','User',1,'udpated'),
	(37,'2018-11-14 12:00:42','2018-11-14 12:00:42','User',1,'udpated'),
	(38,'2018-11-14 12:00:47','2018-11-14 12:00:47','User',1,'udpated'),
	(39,'2018-11-18 00:36:04','2018-11-18 00:36:04','User',1,'udpated'),
	(40,'2018-11-18 00:36:08','2018-11-18 00:36:08','User',1,'udpated'),
	(41,'2018-11-18 23:05:30','2018-11-18 23:05:30','User',1,'udpated'),
	(42,'2018-11-18 23:28:15','2018-11-18 23:28:15','Item',5,'udpated'),
	(43,'2018-11-18 23:29:40','2018-11-18 23:29:40','Item',5,'udpated'),
	(44,'2018-11-19 00:12:42','2018-11-19 00:12:42','User',1,'udpated'),
	(45,'2018-11-19 00:12:46','2018-11-19 00:12:46','User',1,'udpated'),
	(46,'2018-11-19 01:13:19','2018-11-19 01:13:19','User',1,'udpated'),
	(47,'2018-11-19 13:27:55','2018-11-19 13:27:55','User',1,'udpated'),
	(48,'2018-11-19 22:31:18','2018-11-19 22:31:18','User',1,'udpated'),
	(49,'2018-11-19 22:36:13','2018-11-19 22:36:13','User',1,'udpated'),
	(50,'2018-11-19 23:15:20','2018-11-19 23:15:20','User',1,'udpated'),
	(51,'2018-11-19 23:16:08','2018-11-19 23:16:08','User',1,'udpated'),
	(52,'2018-11-20 00:56:05','2018-11-20 00:56:05','User',1,'udpated'),
	(53,'2018-11-20 00:56:08','2018-11-20 00:56:08','User',1,'udpated'),
	(54,'2018-11-20 01:09:44','2018-11-20 01:09:44','User',1,'udpated'),
	(55,'2018-11-20 01:09:47','2018-11-20 01:09:47','User',1,'udpated'),
	(56,'2018-11-20 23:42:44','2018-11-20 23:42:44','User',1,'udpated'),
	(57,'2018-11-20 23:43:44','2018-11-20 23:43:44','Item',5,'udpated'),
	(58,'2018-11-21 19:35:11','2018-11-21 19:35:11','User',1,'udpated'),
	(59,'2018-11-23 00:43:26','2018-11-23 00:43:26','User',1,'udpated'),
	(60,'2018-11-28 23:46:18','2018-11-28 23:46:18','User',1,'udpated'),
	(61,'2018-11-28 23:48:25','2018-11-28 23:48:25','Item',7,'udpated'),
	(62,'2018-11-28 23:48:54','2018-11-28 23:48:54','User',1,'udpated'),
	(63,'2018-11-28 23:48:56','2018-11-28 23:48:56','User',1,'udpated'),
	(64,'2018-11-30 01:00:53','2018-11-30 01:00:53','User',1,'udpated'),
	(65,'2018-11-30 01:02:12','2018-11-30 01:02:12','User',1,'udpated'),
	(66,'2018-12-01 22:48:08','2018-12-01 22:48:08','User',1,'udpated'),
	(67,'2018-12-01 22:48:14','2018-12-01 22:48:14','User',1,'udpated'),
	(68,'2018-12-01 23:27:34','2018-12-01 23:27:34','User',1,'udpated'),
	(69,'2018-12-01 23:28:22','2018-12-01 23:28:22','User',1,'udpated'),
	(70,'2018-12-02 17:07:28','2018-12-02 17:07:28','User',1,'udpated'),
	(71,'2018-12-02 17:07:36','2018-12-02 17:07:36','User',1,'udpated'),
	(72,'2018-12-04 00:29:18','2018-12-04 00:29:18','User',1,'udpated'),
	(73,'2018-12-04 00:29:25','2018-12-04 00:29:25','User',1,'udpated'),
	(74,'2018-12-04 00:30:11','2018-12-04 00:30:11','Customer',1,'udpated'),
	(75,'2018-12-08 14:37:54','2018-12-08 14:37:54','User',1,'udpated'),
	(76,'2018-12-08 14:38:02','2018-12-08 14:38:02','User',1,'udpated'),
	(77,'2018-12-08 14:41:01','2018-12-08 14:41:01','Customer',6,'udpated'),
	(78,'2018-12-08 14:53:21','2018-12-08 14:53:21','Customer',1,'udpated'),
	(79,'2018-12-09 12:51:15','2018-12-09 12:51:15','User',1,'udpated'),
	(80,'2018-12-09 12:51:22','2018-12-09 12:51:22','User',1,'udpated'),
	(81,'2018-12-09 23:54:04','2018-12-09 23:54:04','User',1,'udpated'),
	(82,'2018-12-10 00:04:00','2018-12-10 00:04:00','User',1,'udpated'),
	(83,'2018-12-10 00:50:19','2018-12-10 00:50:19','User',1,'udpated'),
	(84,'2018-12-10 00:50:26','2018-12-10 00:50:26','User',1,'udpated'),
	(85,'2018-12-10 13:18:30','2018-12-10 13:18:30','User',1,'udpated'),
	(86,'2018-12-10 13:19:05','2018-12-10 13:19:05','User',1,'udpated'),
	(87,'2018-12-10 17:26:04','2018-12-10 17:26:04','User',1,'udpated'),
	(88,'2018-12-10 21:34:15','2018-12-10 21:34:15','User',1,'udpated'),
	(89,'2018-12-12 00:02:23','2018-12-12 00:02:23','User',1,'udpated'),
	(90,'2018-12-12 00:02:37','2018-12-12 00:02:37','User',1,'udpated'),
	(91,'2018-12-12 00:04:59','2018-12-12 00:04:59','Customer',6,'udpated'),
	(92,'2018-12-13 00:08:41','2018-12-13 00:08:41','User',1,'udpated'),
	(93,'2018-12-13 01:05:46','2018-12-13 01:05:46','User',1,'udpated'),
	(94,'2018-12-13 01:05:52','2018-12-13 01:05:52','User',1,'udpated'),
	(95,'2018-12-14 23:07:29','2018-12-14 23:07:29','User',1,'udpated'),
	(96,'2018-12-14 23:07:40','2018-12-14 23:07:40','User',1,'udpated'),
	(97,'2018-12-15 00:29:17','2018-12-15 00:29:17','User',1,'udpated'),
	(98,'2018-12-15 00:29:20','2018-12-15 00:29:20','User',1,'udpated'),
	(99,'2018-12-15 00:30:46','2018-12-15 00:30:46','Customer',3,'udpated'),
	(100,'2018-12-15 00:31:40','2018-12-15 00:31:40','Customer',3,'udpated'),
	(101,'2018-12-15 00:36:07','2018-12-15 00:36:07','Customer',3,'udpated'),
	(102,'2018-12-15 00:37:52','2018-12-15 00:37:52','Customer',3,'udpated'),
	(103,'2018-12-15 22:13:49','2018-12-15 22:13:49','User',1,'udpated'),
	(104,'2018-12-15 22:15:45','2018-12-15 22:15:45','Customer',6,'udpated'),
	(105,'2018-12-15 22:19:10','2018-12-15 22:19:10','Customer',6,'udpated'),
	(106,'2018-12-15 22:20:36','2018-12-15 22:20:36','Customer',6,'udpated'),
	(107,'2018-12-15 22:21:16','2018-12-15 22:21:16','Customer',6,'udpated'),
	(108,'2018-12-15 22:22:12','2018-12-15 22:22:12','Customer',6,'udpated'),
	(109,'2018-12-15 22:22:59','2018-12-15 22:22:59','Customer',6,'udpated'),
	(110,'2018-12-15 22:26:11','2018-12-15 22:26:11','Customer',6,'Agreement changed to Signed'),
	(111,'2018-12-15 22:26:11','2018-12-15 22:26:11','Customer',6,'udpated'),
	(112,'2018-12-15 22:26:19','2018-12-15 22:26:19','Customer',6,'udpated'),
	(113,'2018-12-15 23:46:51','2018-12-15 23:46:51','User',1,'udpated'),
	(114,'2018-12-15 23:47:05','2018-12-15 23:47:05','User',1,'udpated'),
	(115,'2018-12-16 14:42:01','2018-12-16 14:42:01','User',1,'udpated'),
	(116,'2018-12-16 14:42:07','2018-12-16 14:42:07','User',1,'udpated'),
	(117,'2018-12-16 14:42:16','2018-12-16 14:42:16','Customer',2,'Agreement Updated'),
	(118,'2018-12-16 14:42:16','2018-12-16 14:42:16','Customer',2,'udpated'),
	(119,'2018-12-16 14:42:43','2018-12-16 14:42:43','Customer',2,'Agreement Updated'),
	(120,'2018-12-16 14:42:43','2018-12-16 14:42:43','Customer',2,'udpated'),
	(121,'2018-12-16 14:46:08','2018-12-16 14:46:08','Customer',1,'Agreement Updated'),
	(122,'2018-12-16 14:46:08','2018-12-16 14:46:08','Customer',1,'udpated'),
	(123,'2018-12-16 14:46:13','2018-12-16 14:46:13','Customer',1,'udpated'),
	(124,'2018-12-16 16:37:28','2018-12-16 16:37:28','User',1,'udpated'),
	(125,'2018-12-16 16:37:31','2018-12-16 16:37:31','User',1,'udpated'),
	(126,'2018-12-16 16:37:36','2018-12-16 16:37:36','Customer',1,'Agreement Updated'),
	(127,'2018-12-16 16:37:43','2018-12-16 16:37:43','Customer',1,'Agreement Updated'),
	(128,'2018-12-16 17:44:10','2018-12-16 17:44:10','User',1,'udpated'),
	(129,'2018-12-16 17:44:15','2018-12-16 17:44:15','User',1,'udpated'),
	(130,'2018-12-16 17:46:59','2018-12-16 17:46:59','Customer',4,'Agreement Updated'),
	(131,'2018-12-16 17:47:19','2018-12-16 17:47:19','Customer',4,'Agreement Updated'),
	(132,'2018-12-16 22:43:17','2018-12-16 22:43:17','User',1,'udpated'),
	(133,'2018-12-16 22:43:25','2018-12-16 22:43:25','User',1,'udpated'),
	(134,'2018-12-16 22:53:26','2018-12-16 22:53:26','Customer',6,'Agreement Updated'),
	(135,'2018-12-16 22:55:15','2018-12-16 22:55:15','User',1,'udpated'),
	(136,'2018-12-16 22:55:17','2018-12-16 22:55:17','User',1,'udpated'),
	(137,'2018-12-16 23:05:02','2018-12-16 23:05:02','Customer',4,'Agreement Updated'),
	(138,'2018-12-16 23:08:27','2018-12-16 23:08:27','Customer',4,'Agreement Updated'),
	(139,'2018-12-16 23:09:01','2018-12-16 23:09:01','Customer',3,'Agreement Updated'),
	(140,'2018-12-16 23:18:29','2018-12-16 23:18:29','User',1,'udpated'),
	(141,'2018-12-16 23:27:31','2018-12-16 23:27:31','User',1,'udpated'),
	(142,'2018-12-16 23:28:12','2018-12-16 23:28:12','User',1,'udpated'),
	(143,'2018-12-16 23:28:42','2018-12-16 23:28:42','User',1,'udpated'),
	(144,'2018-12-17 00:18:56','2018-12-17 00:18:56','User',1,'udpated'),
	(145,'2018-12-17 00:18:58','2018-12-17 00:18:58','User',1,'udpated'),
	(147,'2018-12-17 00:21:04','2018-12-17 00:21:04','Customer',1,'Agreement Updated'),
	(148,'2018-12-17 00:54:02','2018-12-17 00:54:02','User',1,'udpated'),
	(149,'2018-12-17 00:55:10','2018-12-17 00:55:10','User',1,'udpated'),
	(150,'2018-12-17 12:38:27','2018-12-17 12:38:27','User',1,'udpated'),
	(151,'2018-12-17 12:38:45','2018-12-17 12:38:45','Customer',2,'Agreement Updated'),
	(152,'2018-12-18 23:45:39','2018-12-18 23:45:39','User',1,'udpated'),
	(153,'2018-12-18 23:52:15','2018-12-18 23:52:15','Customer',2,'Agreement Updated'),
	(154,'2018-12-18 23:52:23','2018-12-18 23:52:23','Customer',2,'Agreement Updated'),
	(155,'2018-12-19 00:46:11','2018-12-19 00:46:11','User',1,'udpated'),
	(156,'2018-12-19 00:57:21','2018-12-19 00:57:21','User',1,'udpated'),
	(157,'2018-12-19 00:59:18','2018-12-19 00:59:18','User',1,'udpated'),
	(158,'2018-12-19 00:59:34','2018-12-19 00:59:34','User',1,'udpated'),
	(159,'2018-12-19 00:59:43','2018-12-19 00:59:43','User',1,'udpated'),
	(160,'2018-12-19 01:00:31','2018-12-19 01:00:31','User',1,'udpated'),
	(161,'2019-11-06 20:46:33','2019-11-06 20:46:33','User',1,'udpated'),
	(162,'2019-11-07 16:37:06','2019-11-07 16:37:06','User',1,'udpated'),
	(163,'2019-11-08 19:55:05','2019-11-08 19:55:05','User',1,'udpated'),
	(164,'2019-11-08 20:49:38','2019-11-08 20:49:38','User',1,'udpated'),
	(165,'2019-11-08 20:49:42','2019-11-08 20:49:42','User',1,'udpated'),
	(166,'2019-11-08 21:20:01','2019-11-08 21:20:01','User',1,'udpated'),
	(167,'2019-11-08 21:22:23','2019-11-08 21:22:23','User',1,'udpated'),
	(168,'2019-11-12 18:40:14','2019-11-12 18:40:14','User',1,'udpated'),
	(169,'2019-11-12 20:42:04','2019-11-12 20:42:04','User',1,'udpated'),
	(170,'2019-11-12 20:42:08','2019-11-12 20:42:08','User',1,'udpated'),
	(171,'2019-11-13 14:50:25','2019-11-13 14:50:25','User',1,'udpated'),
	(172,'2019-11-13 16:03:44','2019-11-13 16:03:44','User',1,'udpated'),
	(173,'2019-11-13 16:35:16','2019-11-13 16:35:16','User',1,'udpated'),
	(174,'2019-11-13 16:35:19','2019-11-13 16:35:19','User',1,'udpated'),
	(175,'2019-11-13 18:22:22','2019-11-13 18:22:22','User',1,'udpated'),
	(176,'2019-11-13 18:22:24','2019-11-13 18:22:24','User',1,'udpated'),
	(177,'2019-11-13 19:39:42','2019-11-13 19:39:42','User',1,'udpated'),
	(178,'2019-11-13 19:39:46','2019-11-13 19:39:46','User',1,'udpated'),
	(179,'2019-11-13 20:18:17','2019-11-13 20:18:17','Customer',NULL,'Account Created'),
	(180,'2019-11-13 20:58:16','2019-11-13 20:58:16','Customer',NULL,'Account Created'),
	(181,'2019-11-13 21:13:33','2019-11-13 21:13:33','Customer',NULL,'Account Created'),
	(182,'2019-11-13 21:45:08','2019-11-13 21:45:08','User',1,'udpated'),
	(183,'2019-11-13 21:45:11','2019-11-13 21:45:11','User',1,'udpated'),
	(184,'2019-11-14 13:54:02','2019-11-14 13:54:02','User',1,'udpated'),
	(185,'2019-11-14 14:57:13','2019-11-14 14:57:13','User',1,'udpated'),
	(186,'2019-11-14 14:57:17','2019-11-14 14:57:17','User',1,'udpated'),
	(187,'2019-11-14 16:31:39','2019-11-14 16:31:39','User',1,'udpated'),
	(188,'2019-11-14 16:31:43','2019-11-14 16:31:43','User',1,'udpated'),
	(189,'2019-11-14 19:52:35','2019-11-14 19:52:35','User',1,'udpated'),
	(190,'2019-11-14 19:54:02','2019-11-14 19:54:02','Customer',NULL,'Account Created'),
	(191,'2019-11-15 14:50:30','2019-11-15 14:50:30','User',1,'udpated'),
	(192,'2019-11-15 15:53:12','2019-11-15 15:53:12','User',1,'udpated'),
	(193,'2019-11-15 17:52:25','2019-11-15 17:52:25','User',1,'udpated'),
	(194,'2019-11-15 20:11:19','2019-11-15 20:11:19','User',1,'udpated'),
	(195,'2019-11-15 20:11:22','2019-11-15 20:11:22','User',1,'udpated'),
	(196,'2019-11-18 14:59:42','2019-11-18 14:59:42','User',1,'udpated'),
	(197,'2019-11-18 16:05:50','2019-11-18 16:05:50','User',1,'udpated'),
	(198,'2019-11-18 16:05:53','2019-11-18 16:05:53','User',1,'udpated'),
	(199,'2019-11-18 17:44:37','2019-11-18 17:44:37','User',1,'udpated'),
	(200,'2019-11-18 19:22:29','2019-11-18 19:22:29','User',1,'udpated'),
	(201,'2019-11-18 19:22:33','2019-11-18 19:22:33','User',1,'udpated'),
	(202,'2019-11-18 20:49:01','2019-11-18 20:49:01','User',1,'udpated'),
	(203,'2019-11-19 18:18:00','2019-11-19 18:18:00','User',1,'udpated'),
	(204,'2019-11-19 18:55:11','2019-11-19 18:55:11','Item',4,'udpated'),
	(205,'2019-11-19 20:08:48','2019-11-19 20:08:48','User',1,'udpated'),
	(206,'2019-11-19 20:08:54','2019-11-19 20:08:54','User',1,'udpated'),
	(207,'2019-11-25 17:37:46','2019-11-25 17:37:46','User',1,'udpated'),
	(208,'2019-11-26 15:54:22','2019-11-26 15:54:22','User',1,'udpated'),
	(209,'2019-11-26 17:31:41','2019-11-26 17:31:41','User',1,'udpated'),
	(210,'2019-11-26 17:31:43','2019-11-26 17:31:43','User',1,'udpated'),
	(211,'2019-11-26 21:43:20','2019-11-26 21:43:20','User',1,'udpated');

/*!40000 ALTER TABLE `event_logs` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table items
# ------------------------------------------------------------

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;

INSERT INTO `items` (`id`, `description`, `created_at`, `updated_at`, `customer_id`, `price`, `notes`, `type`, `size`, `photo_id`, `clerk`, `status`, `sold_date`, `takein_date`, `pickup_date`, `payout_date`, `payout_amount`, `owing_client`, `paid_client`, `gender`, `item_type`, `item_status`, `payout_pct`, `chk`, `owner`, `item_note`)
VALUES
	(4,'Customer-1-1				','2018-10-28 21:25:07','2019-11-19 18:55:11',1,12.00,'test notes',NULL,'sm',NULL,'Biff',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'man','pnt',NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(5,'Customer-1-2','2018-10-28 21:25:07','2018-11-18 23:29:40',1,23.45,'test notes',NULL,'xs',NULL,'Nancy',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'man','sho',NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(6,'Customer-1-3','2018-10-28 21:25:07','2018-10-28 21:25:07',1,12.00,'test notes',NULL,'md',NULL,'Kalmar',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'woman','jckt',NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(7,'Customer-1-4','2018-10-28 21:25:07','2018-10-28 21:25:07',1,12.00,'test notes',NULL,'lg',NULL,'Trixy',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'girl','tsht',NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(8,'Customer-1-5','2018-10-28 21:25:07','2018-10-28 21:25:07',1,12.00,'test notes',NULL,'lg',NULL,'Janet',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'na','glv',NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(9,'Customer-2-1','2018-10-28 21:25:07','2018-10-28 21:25:07',2,12.00,'test notes',NULL,'na',NULL,'Albright',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'na','acc',NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(10,'Customer-2-2','2018-10-28 21:25:07','2018-10-28 21:25:07',2,12.00,'test notes',NULL,'na',NULL,'Janice',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'na','acc',NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(11,'Customer-2-3','2018-10-28 21:25:07','2018-10-28 21:25:07',2,12.00,'test notes',NULL,'xs',NULL,'shaun',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'na','acc',NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(12,'Customer-2-4','2018-10-28 21:25:07','2018-10-28 21:25:07',2,12.00,'test notes',NULL,'lg',NULL,'Mary',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(13,'Customer-2-5','2018-10-28 21:25:07','2018-10-28 21:25:07',2,12.00,'test notes',NULL,'md',NULL,'Biggee',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(14,'Customer-3-1','2018-10-28 21:25:07','2018-10-28 21:25:07',3,12.00,'test notes',NULL,'na',NULL,'Smalls',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(15,'Customer-3-2','2018-10-28 21:25:07','2018-10-28 21:25:07',3,12.00,'test notes',NULL,'sx',NULL,'Dave',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(16,'Customer-3-3','2018-10-28 21:25:07','2018-10-28 21:25:07',3,12.00,'test notes',NULL,'md',NULL,'Grohl',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(17,'Customer-3-4','2018-10-28 21:25:07','2018-10-28 21:25:07',3,12.00,'test notes',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(18,'Customer-3-5','2018-10-28 21:25:07','2018-10-28 21:25:07',3,12.00,'test notes',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(19,'Left handed','2018-10-28 21:58:41','2018-10-28 21:58:41',2,1.00,'test notes',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(20,'shirt','2018-10-28 22:06:39','2018-10-28 22:06:39',2,123.00,'test notes',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(21,'shirt','2018-10-28 22:07:00','2018-10-28 22:07:00',2,123.00,'test notes',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(22,'shirt','2018-10-28 22:08:00','2018-10-28 22:08:00',2,123.00,'test notes',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(23,'shirt','2018-10-28 22:08:21','2018-10-28 22:08:21',2,123.00,'test notes',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(24,'shirt','2018-10-28 22:33:13','2018-10-28 22:33:13',2,123.00,'test notes',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(25,'headbands','2018-10-28 22:34:38','2018-10-28 22:34:38',2,23.00,'test notes',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(26,'headbands','2018-10-28 22:37:08','2018-10-28 22:37:08',2,23.00,'test notes',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(27,'headbands','2018-10-28 22:37:53','2018-10-28 22:37:53',2,23.00,'test notes',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(28,'headbands','2018-10-28 22:38:29','2018-10-28 22:38:29',2,23.00,'test notes',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(29,'headbands','2018-10-28 22:38:49','2018-10-28 22:38:49',2,23.00,'test notes',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(30,'headbands','2018-10-28 22:39:21','2018-10-28 22:39:21',2,23.00,'test notes',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(31,'headbands','2018-10-28 22:41:16','2018-10-28 22:41:16',2,23.00,'test notes',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(34,'shirt','2018-10-28 23:01:12','2018-10-28 23:01:12',2,23.00,'test notes',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(35,'Pants','2018-10-28 23:04:20','2018-10-28 23:04:20',4,1.00,'test notes',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?'),
	(36,'Socks','2018-10-28 23:18:01','2018-10-28 23:18:01',3,45.00,'test notes',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?');

/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table photos
# ------------------------------------------------------------



# Dump of table schema_migrations
# ------------------------------------------------------------

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;

INSERT INTO `schema_migrations` (`version`)
VALUES
	('20181013192524'),
	('20181014151146'),
	('20181016171704'),
	('20181017172824'),
	('20181024005001'),
	('20181026235647'),
	('20181027000955'),
	('20181027005842'),
	('20181027212110'),
	('20181028230955'),
	('20181029214911'),
	('20181030195707'),
	('20181104221029'),
	('20181112200516'),
	('20181124170853'),
	('20181124172427'),
	('20181204001828'),
	('20181204002350'),
	('20181208003920'),
	('20181208010301'),
	('20181225134859'),
	('20181227212003'),
	('20181227213502'),
	('20190106210047'),
	('20190112142033'),
	('20190113215943'),
	('20190113220651'),
	('20190113221715'),
	('20190114180446'),
	('20190114181449'),
	('20190119003329'),
	('20190119225919'),
	('20190119230332'),
	('20190124003449'),
	('20190124152652'),
	('20191117180037'),
	('20191122223022');

/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table take_ins
# ------------------------------------------------------------



# Dump of table users
# ------------------------------------------------------------

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;

INSERT INTO `users` (`id`, `email`, `encrypted_password`, `reset_password_token`, `reset_password_sent_at`, `remember_created_at`, `created_at`, `updated_at`, `first_name`, `last_name`, `phone`, `type`, `sign_in_count`, `current_sign_in_at`, `last_sign_in_at`, `current_sign_in_ip`, `last_sign_in_ip`)
VALUES
	(1,'admin@test.com','$2a$11$kUgAbVzAMP99U.uf9x1QCe2tcO4dc6KWqhWIZ6JBuD83CnUxmX3au',NULL,NULL,NULL,'2018-10-28 21:22:14','2019-11-26 21:43:20','admin','user','555-555-1212','AdminUser',79,'2019-11-26 21:43:20','2019-11-26 17:31:43','::1','::1'),
	(2,'user@test.com','$2a$11$gVuvdGoOa1Y1kwSd4P73UOCIZIZigeSnZTTpw667wZn3IJuAQt.KC',NULL,NULL,NULL,'2018-10-28 21:22:14','2018-10-28 21:22:14','user','name','555-555-1212',NULL,0,NULL,NULL,NULL,NULL);

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
